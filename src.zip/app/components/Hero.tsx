import image_6adb3ad903c1e8b4f2a5025fc3714b804847f5b0 from 'figma:asset/6adb3ad903c1e8b4f2a5025fc3714b804847f5b0.png'
import { ArrowRight } from "lucide-react";
import { motion } from "motion/react";
import imgLogo from "figma:asset/349a27acdbe266a7e9728df07ae22d1db56214bf.png";
import imgTagline from "figma:asset/d539dc10471cc334f8aab0089e8f695a90a94c8e.png";
import { useLanguage } from "../context/LanguageContext";
const imgBg  = "https://i.imgur.com/36mR3vR.jpeg";
const img_tag = "https://i.imgur.com/EdLebEx.png"

export function Hero() {
  const { t, lang } = useLanguage();

  return (
    <section
      id="intro"
      className="relative min-h-screen flex items-center justify-center overflow-hidden"
    >
      {/* 배경 그라디언트 */}
      <div className="absolute inset-0 bg-[#FEFFF6]" />

      {/* 하늘/풀밭 일러스트 배경 */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <img
          src={imgBg}
          alt=""
          className="absolute inset-0 w-full h-full object-cover object-bottom"
        />
      </div>

      {/* 콘텐츠 */}
      <div className="relative z-10 w-full max-w-4xl mx-auto px-4 text-center pt-28 pb-16">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="flex flex-col items-center gap-12 md:gap-7"
        >
        <div className="max-w-screen-lg mx-auto flex flex-col items-center gap-4">
          {/* 로고 슬롯 1 - 상단 이미지퐁당 5주년*/}
          <div className="flex justify-center w-50">
            <img
              src={img_tag}
              alt={t("hero.tagline")}
              className="w-full max-w-[360px] md:max-w-[480px] h-auto object-contain"
            />
          </div>

          {/* 로고 슬롯 2 - 태그라인 이미지 */}
          <div className="flex justify-center w-full">
            <img
              src={image_6adb3ad903c1e8b4f2a5025fc3714b804847f5b0}
              alt={t("hero.tagline")}
              className="w-full max-w-[360px] md:max-w-[480px] h-auto object-contain"
            />
          </div>
        </div>

          {/* 힐링보이스 로고 */}
          <div className="flex justify-center w-full">
            <img
              src={imgLogo}
              alt="힐링보이스"
              className="w-full max-w-[520px] h-auto object-contain drop-shadow-sm"
            />
          </div>

          {/* 설명 텍스트 컨테이너: max-w를 조금 더 넉넉하게 잡거나 없애서 한 줄 확보 */}
          <div className="text-[#101828] max-w-4xl mx-auto space-y-2 text-center"> 
            
            {/* 첫 번째 줄 */}
            <p className="text-[18px] md:text-[28px] font-semibold leading-snug md:leading-[28px] tracking-normal break-keep md:whitespace-nowrap">
              <span>"{t("hero.descPart1")}</span>
              <span>{t("hero.descPart2")}</span>
              <span className="font-black text-[#0084d1]">CCM</span>
              <span>{t("hero.descPart3")}"</span>
            </p>
          
            {/* 두 번째 줄 */}
            <p className="text-[20px] md:text-[28px] font-semibold leading-snug md:leading-[28px] tracking-normal break-keep md:whitespace-nowrap">
              {t("hero.descPart4")}
            </p>
            
          </div>

          {/* 모집 기간 뱃지 (노랑-연두) */}
          <div className="bg-[#e9ed7f] rounded-[10px] shadow-sm px-[24px] py-[20px]">
            <p className="font-medium text-[#101828] text-lg md:text-2xl text-center break-keep md:whitespace-nowrap">
              {t("hero.period")}
            </p>
          </div>

          {/* CTA 버튼 */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center w-full max-w-lg h-16">
            <button
              onClick={() =>
                document
                  .getElementById("steps")
                  ?.scrollIntoView({ behavior: "smooth" })
              }
              className="flex-1 bg-[#00a6f4] hover:bg-[#0095e0] text-white font-bold text-lg md:text-xl px-8 py-4 rounded-full transition-all hover:scale-105 active:scale-95 shadow-[0_0_20px_rgba(14,165,233,0.4)] whitespace-nowrap"
            >
              {t("hero.downloadBtn")}
            </button>
            <button
              onClick={() =>
                document
                  .getElementById("info")
                  ?.scrollIntoView({ behavior: "smooth" })
              }
              className="flex-1 bg-white hover:bg-sky-50 text-[#44a9ff] font-bold text-lg md:text-xl px-8 py-4 rounded-full transition-all flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(14,135,190,0.2)] whitespace-nowrap"
            >
              {t("hero.infoBtn")}
              <ArrowRight className="w-5 h-5 text-[#44a9ff] shrink-0" />
            </button>
          </div>
        </motion.div>
      </div>
    </section>
  );
}